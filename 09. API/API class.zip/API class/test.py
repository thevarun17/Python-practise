a = 10
b = 10
res = a is b
print(res)

x = [10,20]
y = [10,20]
res = y is x
print(res)